/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp5part3;



import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;

// Class for user registration and login
class User {
    String username;
    String password;
    String phoneNumber;
    boolean registered = false;

    boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    boolean isValidPassword(String password) {
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    boolean isValidPhoneNumber(String phone) {
        return phone.matches("\\+27\\d{9}");
    }

    String register(String username, String password, String phone) {
        if (!isValidUsername(username)) {
            return "Username must contain '_' and be at most 5 characters.";
        }
        if (!isValidPassword(password)) {
            return "Password must be at least 8 characters with uppercase, number, and special char.";
        }
        if (!isValidPhoneNumber(phone)) {
            return "Phone number must start with +27 and have 9 digits.";
        }
        this.username = username;
        this.password = password;
        this.phoneNumber = phone;
        this.registered = true;
        return "Registration successful!";
    }

    boolean login(String username, String password) {
        return registered && this.username.equals(username) && this.password.equals(password);
    }
}

// Class to hold message data
class ChatMessage implements Serializable {
    String id;
    String recipientPhone;
    String content;
    String status;  // 
    String senderPhone;

    ChatMessage(String id, String recipientPhone, String content, String status, String senderPhone) {
        this.id = id;
        this.recipientPhone = recipientPhone;
        this.content = content;
        this.status = status;
        this.senderPhone = senderPhone;
    }
}

// Class to manage messages
class MessageHandler {
    //all messages sent, stored,disregarded
    ArrayList<ChatMessage> allMessages; 
    private User user;
    private final String FILE_NAME = "chatMessages.dat";

    // Arrays 
    ArrayList<ChatMessage> sentMessages;
    private ArrayList<ChatMessage> disregardedMessages;
    private ArrayList<ChatMessage> storedMessages;
    private ArrayList<String> messageHashes;
    private ArrayList<String> messageIDs;

    MessageHandler(User user) {
        this.user = user;
        allMessages = new ArrayList<>();
        sentMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        messageHashes = new ArrayList<>();
        messageIDs = new ArrayList<>();
        loadMessages();
        populateArrays();
    }

    // Loads saved messages from file
    @SuppressWarnings("unchecked")
    void loadMessages() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            allMessages = (ArrayList<ChatMessage>) ois.readObject();
        } catch (Exception e) {
            allMessages = new ArrayList<>();
        }
    }

    // Saves all messages to file
    void saveMessages() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(allMessages);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }

    // Makes arrays from allMessages list
    void populateArrays() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();

        for (ChatMessage m : allMessages) {
            if (m.status.equalsIgnoreCase("Sent")) {
                sentMessages.add(m);
            } else if (m.status.equalsIgnoreCase("Disregarded")) {
                disregardedMessages.add(m);
            } else if (m.status.equalsIgnoreCase("Stored")) {
                storedMessages.add(m);
            }
            messageIDs.add(m.id);
            messageHashes.add(generateHash(m));
        }
    }

    // Simple hash generator 
    String generateHash(ChatMessage m) {
        int sum = 0;
        String combined = m.id + m.recipientPhone + m.content;
        for (int i = 0; i < combined.length(); i++) {
            sum += combined.charAt(i);
        }
        return String.format("%05d", sum % 100000);
    }

    // Generate  10 digit ID
    String generateMessageId() {
        Random random = new Random();
        String id;
        do {
            id = String.format("%010d", random.nextInt(1_000_000_000));
        } while (messageIDs.contains(id));
        return id;
    }

    boolean isValidRecipient(String phone) {
        return user.isValidPhoneNumber(phone);
    }

    // Send message, store with status "Sent"
    void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27XXXXXXXXX):");
        if (recipient == null) return;
        if (!isValidRecipient(recipient)) {
            JOptionPane.showMessageDialog(null, "Invalid phone number format.");
            return;
        }

        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (message == null) return;
        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message too long! Max 250 characters allowed.");
            return;
        }

        String msgId = generateMessageId();

        int choice = JOptionPane.showConfirmDialog(null,
                "Message ID: " + msgId +
                        "\nTo: " + recipient +
                        "\nMessage: " + message +
                        "\n\nSend this message?",
                "Confirm Send",
                JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            ChatMessage newMessage = new ChatMessage(msgId, recipient, message, "Sent", user.phoneNumber);
            allMessages.add(newMessage);
            saveMessages();
            populateArrays();
            JOptionPane.showMessageDialog(null, "Message sent and saved!");
        } else {
            ChatMessage newMessage = new ChatMessage(generateMessageId(), recipient, message, "Disregarded", user.phoneNumber);
            allMessages.add(newMessage);
            saveMessages();
            populateArrays();
            JOptionPane.showMessageDialog(null, "Message discarded.");
        }
    }

    // Show last 5 messages sent or stored
    void showRecentMessages() {
        if (allMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages to show.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, allMessages.size() - 5);
        for (int i = allMessages.size() - 1; i >= start; i--) {
            ChatMessage msg = allMessages.get(i);
            sb.append("ID: ").append(msg.id)
              .append(", To: ").append(msg.recipientPhone)
              .append(", Msg: ").append(msg.content)
              .append(", Status: ").append(msg.status)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    // Display sender and recipient of all sent messages
    void displaySendersRecipients() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to show.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (ChatMessage m : sentMessages) {
            sb.append("Sender: ").append(m.senderPhone)
              .append(", Recipient: ").append(m.recipientPhone)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Senders and Recipients", JOptionPane.INFORMATION_MESSAGE);
    }

    // Display the longest sent message
    void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        ChatMessage longest = sentMessages.get(0);
        for (ChatMessage m : sentMessages) {
            if (m.content.length() > longest.content.length()) {
                longest = m;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest message:\n" + longest.content);
    }

    // Search for message by ID and show recipient and message content
    void searchByMessageID() {
        String searchId = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (searchId == null || searchId.trim().isEmpty()) return;

        for (ChatMessage m : allMessages) {
            if (m.id.equals(searchId.trim())) {
                JOptionPane.showMessageDialog(null, "Recipient: " + m.recipientPhone + "\nMessage: " + m.content);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // Search all messages sent or stored to a recipient
    void searchByRecipient() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number to search:");
        if (recipient == null || recipient.trim().isEmpty()) return;

        StringBuilder sb = new StringBuilder();
        for (ChatMessage m : allMessages) {
            if (m.recipientPhone.equals(recipient.trim()) && (m.status.equalsIgnoreCase("Sent") || m.status.equalsIgnoreCase("Stored"))) {
                sb.append(m.content).append("\n");
            }
        }
        if (sb.length() == 0) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient " + recipient);
        } else {
            JOptionPane.showMessageDialog(null, "Messages for " + recipient + ":\n" + sb.toString());
        }
    }

    // Delete message using message hash
    void deleteByHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (hash == null || hash.trim().isEmpty()) return;

        for (int i = 0; i < allMessages.size(); i++) {
            ChatMessage m = allMessages.get(i);
            if (generateHash(m).equals(hash.trim())) {
                allMessages.remove(i);
                saveMessages();
                populateArrays();
                JOptionPane.showMessageDialog(null, "Message \"" + m.content + "\" successfully deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }

    // Display report with all sent messages 
    void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to show.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (ChatMessage m : sentMessages) {
            sb.append("Hash: ").append(generateHash(m))
              .append(", Recipient: ").append(m.recipientPhone)
              .append(", Message: ").append(m.content)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
    }

   // Add  test data 
    void addTestData() {
        
        allMessages.clear();

        allMessages.add(new ChatMessage("0000000001", "+27834557896", "Did you get the cake?", "Sent", user.phoneNumber));
        allMessages.add(new ChatMessage("0000000002", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", user.phoneNumber));
        allMessages.add(new ChatMessage("0000000003", "+27834484567", "Yohoooo, I am at your gate.", "Disregarded", user.phoneNumber));
        allMessages.add(new ChatMessage("0838884567", "0838884567", "It is dinner time !", "Sent", user.phoneNumber));
        allMessages.add(new ChatMessage("0000000005", "+27838884567", "Ok, I am leaving without you.", "Stored", user.phoneNumber));

        saveMessages();
        populateArrays();
        JOptionPane.showMessageDialog(null, "Test data added!");
    }
}

// Main class to run the quickchatapp
public class Quickchatapp5Part3 {
    public static void main(String[] args) {
        User user = new User();

        while (true) {
            String username = JOptionPane.showInputDialog("Register - Enter username:");
            String password = JOptionPane.showInputDialog("Register - Enter password:");
            String phone = JOptionPane.showInputDialog("Register - Enter South African phone number (+27XXXXXXXXX):");

            if (username == null || password == null || phone == null) {
                JOptionPane.showMessageDialog(null, "Registration cancelled.");
                return;
            }

            String result = user.register(username.trim(), password.trim(), phone.trim());
            JOptionPane.showMessageDialog(null, result);

            if (result.equals("Registration successful!")) break;
        }

        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        boolean loggedIn = false;
        while (!loggedIn) {
            String username = JOptionPane.showInputDialog("Login - Enter username:");
            String password = JOptionPane.showInputDialog("Login - Enter password:");

            if (username == null || password == null) {
                JOptionPane.showMessageDialog(null, "Login cancelled.");
                return;
            }

            loggedIn = user.login(username.trim(), password.trim());
            if (loggedIn) {
                JOptionPane.showMessageDialog(null, "Welcome " + firstName + " " + lastName + "!");
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect username or password, try again.");
            }
        }

        MessageHandler messageHandler = new MessageHandler(user);

        // Menu loop with new options
        while (true) {
            String menu = "Menu:\n" +
                    "1. Send Message\n" +
                    "2. View Recent Messages\n" +
                    "3. Display senders and recipients of sent messages\n" +
                    "4. Display longest sent message\n" +
                    "5. Search message by ID\n" +
                    "6. Search messages by recipient\n" +
                    "7. Delete message by hash\n" +
                    "8. Display sent messages report\n" +
                    "9. Add test data\n" +
                    "10. Quit\n" +
                    "Enter choice:";

            String choice = JOptionPane.showInputDialog(menu);
            if (choice == null) break;

            switch (choice) {
                case "1" -> messageHandler.sendMessage();
                case "2" -> messageHandler.showRecentMessages();
                case "3" -> messageHandler.displaySendersRecipients();
                case "4" -> messageHandler.displayLongestMessage();
                case "5" -> messageHandler.searchByMessageID();
                case "6" -> messageHandler.searchByRecipient();
                case "7" -> messageHandler.deleteByHash();
                case "8" -> messageHandler.displayReport();
                case "9" -> messageHandler.addTestData();
                case "10" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye! Thanks for using QuickChat.");
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Try again.");
            }
        }
    }
}

