/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quickchatapp5part3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class MessageHandlerTest {
    
    public MessageHandlerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of loadMessages method, of class MessageHandler.
     */
    @Test
    public void testLoadMessages() {
        System.out.println("loadMessages");
        MessageHandler instance = null;
        instance.loadMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of saveMessages method, of class MessageHandler.
     */
    @Test
    public void testSaveMessages() {
        System.out.println("saveMessages");
        MessageHandler instance = null;
        instance.saveMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of populateArrays method, of class MessageHandler.
     */
    @Test
    public void testPopulateArrays() {
        System.out.println("populateArrays");
        MessageHandler instance = null;
        instance.populateArrays();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateHash method, of class MessageHandler.
     */
    @Test
    public void testGenerateHash() {
        System.out.println("generateHash");
        ChatMessage m = null;
        MessageHandler instance = null;
        String expResult = "";
        String result = instance.generateHash(m);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageId method, of class MessageHandler.
     */
    @Test
    public void testGenerateMessageId() {
        System.out.println("generateMessageId");
        MessageHandler instance = null;
        String expResult = "";
        String result = instance.generateMessageId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidRecipient method, of class MessageHandler.
     */
    @Test
    public void testIsValidRecipient() {
        System.out.println("isValidRecipient");
        String phone = "";
        MessageHandler instance = null;
        boolean expResult = false;
        boolean result = instance.isValidRecipient(phone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessage method, of class MessageHandler.
     */
    @Test
    public void testSendMessage() {
        System.out.println("sendMessage");
        MessageHandler instance = null;
        instance.sendMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showRecentMessages method, of class MessageHandler.
     */
    @Test
    public void testShowRecentMessages() {
        System.out.println("showRecentMessages");
        MessageHandler instance = null;
        instance.showRecentMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySendersRecipients method, of class MessageHandler.
     */
    @Test
    public void testDisplaySendersRecipients() {
        System.out.println("displaySendersRecipients");
        MessageHandler instance = null;
        instance.displaySendersRecipients();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongestMessage method, of class MessageHandler.
     */
    @Test
    public void testDisplayLongestMessage() {
        System.out.println("displayLongestMessage");
        MessageHandler instance = null;
        instance.displayLongestMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByMessageID method, of class MessageHandler.
     */
    @Test
    public void testSearchByMessageID() {
        System.out.println("searchByMessageID");
        MessageHandler instance = null;
        instance.searchByMessageID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByRecipient method, of class MessageHandler.
     */
    @Test
    public void testSearchByRecipient() {
        System.out.println("searchByRecipient");
        MessageHandler instance = null;
        instance.searchByRecipient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteByHash method, of class MessageHandler.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        MessageHandler instance = null;
        instance.deleteByHash();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayReport method, of class MessageHandler.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        MessageHandler instance = null;
        instance.displayReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTestData method, of class MessageHandler.
     */
    @Test
    public void testAddTestData() {
        System.out.println("addTestData");
        MessageHandler instance = null;
        instance.addTestData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
