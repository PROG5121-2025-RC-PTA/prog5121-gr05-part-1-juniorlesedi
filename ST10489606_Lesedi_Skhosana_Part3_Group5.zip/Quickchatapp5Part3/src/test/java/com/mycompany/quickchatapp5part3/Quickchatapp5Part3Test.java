/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quickchatapp5part3;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;



// JUnit 5 tests for User and MessageHandler
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class Quickchatapp5Part3Test {

    static User user;
    static MessageHandler messageHandler;

    @BeforeAll
    static void setup() {
        user = new User();
        user.register("usr_", "Passw0rd!", "+27123456789");
        messageHandler = new MessageHandler(user);
    }

    @Test
    @Order(1)
    void testUsernameValidation() {
        assertTrue(user.isValidUsername("ab_c"));
        assertFalse(user.isValidUsername("abcde"));  // No underscore
        assertFalse(user.isValidUsername("abcdef")); // > 5 chars
    }

    @Test
    @Order(2)
    void testPasswordValidation() {
        assertTrue(user.isValidPassword("Abcdef1!"));
        assertFalse(user.isValidPassword("abcdef1!")); 
        assertFalse(user.isValidPassword("ABCDEFGH!"));
        assertFalse(user.isValidPassword("Abcdefgh1"));
        assertFalse(user.isValidPassword("Ab1!"));      
    }

    @Test
    @Order(3)
    void testPhoneNumberValidation() {
        assertTrue(user.isValidPhoneNumber("+27123456789"));
        assertFalse(user.isValidPhoneNumber("0712345678"));  
        assertFalse(user.isValidPhoneNumber("+2712345678"));
    }

    @Test
    @Order(4)
    void testRegisterAndLogin() {
        User u = new User();
        String result = u.register("test_", "Test1234!", "+27111222333");
        assertEquals("Registration successful!", result);
        assertTrue(u.login("test_", "Test1234!"));
        assertFalse(u.login("test_", "wrongpass"));
    }

    @Test
    @Order(5)
    void testGenerateMessageIdUnique() {
        messageHandler.addMessage(new ChatMessage("0000000001", "+27123456789", "Hi", "Sent", "+27111222333"));
        messageHandler.populateArrays();
        String newId = messageHandler.generateMessageId();
        assertNotEquals("0000000001", newId);
        assertEquals(10, newId.length());
    }

    @Test
    @Order(6)
    void testGenerateHashLength() {
        ChatMessage msg = new ChatMessage("0000000001", "+27123456789", "Hello", "Sent", "+27111222333");
        String hash = messageHandler.generateHash(msg);
        assertNotNull(hash);
        assertEquals(5, hash.length());
    }

    @Test
    @Order(7)
    void testPopulateArrays() {
        ChatMessage sentMsg = new ChatMessage("0000000001", "+27123456789", "Hello", "Sent", "+27111222333");
        ChatMessage storedMsg = new ChatMessage("0000000002", "+27123456780", "Stored message", "Stored", "+27111222333");
        ChatMessage disregardedMsg = new ChatMessage("0000000003", "+27123456781", "Discarded message", "Disregarded", "+27111222333");

        messageHandler.addMessage(sentMsg);
        messageHandler.addMessage(storedMsg);
        messageHandler.addMessage(disregardedMsg);

        messageHandler.populateArrays();

        assertEquals(1, messageHandler.getSentMessages().size());
        assertEquals(1, messageHandler.getStoredMessages().size());
        assertEquals(1, messageHandler.getDisregardedMessages().size());

        assertTrue(messageHandler.getMessageIDs().contains("0000000001"));
        assertTrue(messageHandler.getMessageIDs().contains("0000000002"));
        assertTrue(messageHandler.getMessageIDs().contains("0000000003"));
    }

    @Test
    @Order(8)
    void testIsValidRecipient() {
        assertTrue(messageHandler.isValidRecipient("+27123456789"));
        assertFalse(messageHandler.isValidRecipient("0712345678"));
    }
}
