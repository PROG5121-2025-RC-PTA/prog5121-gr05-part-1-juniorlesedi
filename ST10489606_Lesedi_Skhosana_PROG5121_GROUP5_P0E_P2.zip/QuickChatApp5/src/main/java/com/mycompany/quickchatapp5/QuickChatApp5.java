/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp5;


import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;

// Class for user registration and login
class User {
    //Declarations
    String username;
    String password;
    String phoneNumber;
    boolean registered = false;

    // Check if username contains "_" and max 5 chars
    boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Checking if password is at least 8 chars, one uppercase, one number, one special char
    boolean isValidPassword(String password) {
        return password.length() >= 8
                && password.matches(".*[A-Z].*") 
                && password.matches(".*\\d.*")    
                && password.matches(".*[^a-zA-Z0-9].*"); 
    }

    // Check if phone number starts with +27 and 9 digits after
    boolean isValidPhoneNumber(String phone) {
        return phone.matches("\\+27\\d{9}");
    }

    // checking if username,password and phone number are valid
    String register(String username, String password, String phone) {
        if (!isValidUsername(username)) {
            return "Username must contain '_' and be at most 5 characters.";
        }
        if (!isValidPassword(password)) {
            return "Password must be at least 8 characters with uppercase, number, and special char.";
        }
        if (!isValidPhoneNumber(phone)) {
            return "Phone number must start with +27 and have 9 digits.";
        }
        this.username = username;
        this.password = password;
        this.phoneNumber = phone;
        this.registered = true;
        return "Registration successful!";
    }

    // To Check login credentials
    boolean login(String username, String password) {
        return registered && this.username.equals(username) && this.password.equals(password);
    }
}

// Class to hold message data
class ChatMessage implements Serializable {
    //Declarations
    String id;
    String recipientPhone;
    String content;

    ChatMessage(String id, String recipientPhone, String content) {
        this.id = id;
        this.recipientPhone = recipientPhone;
        this.content = content;
    }
}

// Class to manage messages
class MessageHandler {
    private ArrayList<ChatMessage> messageList;
    private final User user;
    private final String FILE_NAME = "chatMessages.dat";

    MessageHandler(User user) {
        this.user = user;
        messageList = new ArrayList<>();
        loadMessages();
    }

    // Loading saved messages from file
    @SuppressWarnings("unchecked")
    void loadMessages() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            messageList = (ArrayList<ChatMessage>) ois.readObject();
        } catch (Exception e) {
            // Starting with empty list if file not found or error
            messageList = new ArrayList<>();
        }
    }

    // Saves messages to file
    void saveMessages() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(messageList);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
        }
    }

    // Generating  10-digit ID for message
    String generateMessageId() {
        Random random = new Random();
        String id;
        do {
            id = String.format("%010d", random.nextInt(1_000_000_000));
        } while (idExists(id));
        return id;
    }

    // Check if ID already used
    boolean idExists(String id) {
        for (ChatMessage m : messageList) {
            if (m.id.equals(id))
               return true;
        }
        return false;
    }

    // Check if recipient phone is valid
    boolean isValidRecipient(String phone) {
        return user.isValidPhoneNumber(phone);
    }

    // Send a message inputed by user
    void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27XXXXXXXXX):");
        if (recipient == null) 
            return; 
        if (!isValidRecipient(recipient)) {
            JOptionPane.showMessageDialog(null, "Invalid phone number format.");
            return;
        }

        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (message == null) 
            return;
        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message too long! Max 250 characters allowed.");
            return;
        }

        String msgId = generateMessageId();

        int choice = JOptionPane.showConfirmDialog(null,
                "Message ID: " + msgId +
                        "\nTo: " + recipient +
                        "\nMessage: " + message +
                        "\n\nSend this message?",
                "Confirm Send",
                JOptionPane.YES_NO_OPTION);
//
        if (choice == JOptionPane.YES_OPTION) {
            ChatMessage newMessage = new ChatMessage(msgId, recipient, message);
            messageList.add(newMessage);
            saveMessages();
            JOptionPane.showMessageDialog(null, "Message sent and saved!");
        } else {
            JOptionPane.showMessageDialog(null, "Message discarded.");
        }
    }

    // Show last 5 messages sent
    void showRecentMessages() {
        if (messageList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages to show.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, messageList.size() - 5);
        for (int i = messageList.size() - 1; i >= start; i--) {
            ChatMessage msg = messageList.get(i);
            sb.append("ID: ").append(msg.id)
              .append(", To: ").append(msg.recipientPhone)
              .append(", Msg: ").append(msg.content)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
}

// Main class to run the quickchatapp
public class QuickChatApp5 {
    public static void main(String[] args) {
        User user = new User();

        // Using while loop for Registration
        while (true) {
            String username = JOptionPane.showInputDialog("Register - Enter username:");
            String password = JOptionPane.showInputDialog("Register - Enter password:");
            String phone = JOptionPane.showInputDialog("Register - Enter South African phone number (+27XXXXXXXXX):");

            // if user cancel
            if (username == null || password == null || phone == null) {
                JOptionPane.showMessageDialog(null, "Registration cancelled.");
                return; 
            }

            String result = user.register(username.trim(), password.trim(), phone.trim());
            JOptionPane.showMessageDialog(null, result);

            if (result.equals("Registration successful!")) break;
        }

        // Ask for first and last name (just for welcome message)
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        // Login loop
        boolean loggedIn = false;
        while (!loggedIn) {
            String username = JOptionPane.showInputDialog("Login - Enter username:");
            String password = JOptionPane.showInputDialog("Login - Enter password:");

            if (username == null || password == null) {
                JOptionPane.showMessageDialog(null, "Login cancelled.");
                return;
            }

            loggedIn = user.login(username.trim(), password.trim());
            if (loggedIn) {
                JOptionPane.showMessageDialog(null, "Welcome " + firstName + " " + lastName + "!");
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect username or password, try again.");
            }
        }

        MessageHandler messageHandler = new MessageHandler(user);

        // Menu loop
        while (true) {
            String choice = JOptionPane.showInputDialog(
                    "Menu:\n1. Send Message\n2. View Recent Messages\n3. Quit\nEnter choice:");
            
             //if user cancelled
            if (choice == null) 
                break; 

            switch (choice) {
                case "1" -> messageHandler.sendMessage();
                case "2" -> messageHandler.showRecentMessages();
                case "3" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye! Thanks for using QuickChat.");
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }
}
