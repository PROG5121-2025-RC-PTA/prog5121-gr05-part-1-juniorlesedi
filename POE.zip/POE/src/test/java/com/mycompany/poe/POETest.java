/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class POETest {
    
     @org.junit.jupiter.api.Test
    public void testCheckUsername() {
        System.out.println("checkUsername");
        String username = "kyl_1";
        boolean result = POE.checkUsername(username);
        assertTrue(result);
        
        String usernamein = "kyle!!!!";
        boolean resultin = POE.checkUsername(usernamein);
        assertTrue(resultin);
        
    }

    /**
     * Test of checkpasswordcomplexity method, of class POE.
     */
    @org.junit.jupiter.api.Test
    public void testCheckpasswordcomplexity() {
       
        
        String password = "Ch&&sec@ke99!!";
        boolean result = POE.checkpasswordcomplexity(password);
        assertTrue(result);
       
        String password2 = "Ch&&sec@ke99!!";
        boolean result2 = POE.checkpasswordcomplexity(password2);
        assertTrue(result2);
    }

    /**
     * Test of checkcellphonenumber method, of class POE.
     */
    @org.junit.jupiter.api.Test
    public void testCheckcellphonenumber() {
        String cellphonenumber = "+27793592801";
        boolean result = POE.checkcellphonenumber(cellphonenumber);
        assertTrue(result);
        
         String cellphonenumber1 = "0895245";
        boolean result1 = POE.checkcellphonenumber(cellphonenumber1);
        assertFalse(result1);
        
        
    }

    /**
     * Test of registerUser method, of class POE.
     */
    @org.junit.jupiter.api.Test
    public void testRegisterUser() {
    
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!!";
        String phone = "+27793592801";
        String expResult = "Sucessfully logged into BigScar";
        String result = POE.registerUser(username, password, phone);
        assertEquals(expResult, result);
        
        String username2 = "kyle!!!";
        String password2 = "passward";
        String phone2 = "+27793592801";
        String expResult2 = "Unable to login,Please try again";
        String result2 = POE.registerUser(username2, password2, phone2);
        assertEquals(expResult2, result2);
        
    }

    /**
     * Test of loginUser method, of class POE.
     */
    @org.junit.jupiter.api.Test
    public void testLoginUser() {
       
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!!";
      
        boolean result = POE.loginUser(username, password);
        assertTrue( result);
        
        String username2 = "kyle!!!!";
        String password2 = "password";
       
        boolean result2 = POE.loginUser(username2, password2);
        assertTrue(result2);
        
    }

    /**
     * Test of returnLoginStatus method, of class POE.
     */
    @org.junit.jupiter.api.Test
    public void testReturnLoginStatus() {
      
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!!";
        String expResult = "You have successfully logged in";
        String result = POE.returnLoginStatus(username, password);
        assertEquals(expResult, result);
        
        String username2 = "kyle!!!!";
        String password2 = "password";
        String expResult2 = "Failed to log in!!";
        String result2 = POE.returnLoginStatus(username2, password2);
        assertEquals(expResult2, result2);
        
        
        
    }
    
}
