/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.*;


/**
 *
 * @author RC_Student_lab
 */
public class POE {
    static String[] cell = new String[5];
    static String[] userN = new String[5];
    static String[] pass = new String[5];
    static int num = 0;
    

    public static void main(String[] args) {
        JFrame frame = new JFrame("Register to BigScar");
        frame.setVisible(true);
        frame.setSize(450,450);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Color.CYAN);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setLayout(null);
        
        JLabel label= new JLabel("Welcome to BigScar, please register");
        frame.add(label);
        label .setBounds(40, 30, 250, 100);
        
          JLabel username= new JLabel("username");
        frame.add(username);
        username .setBounds(50, 80, 150, 100);
        
          JLabel password= new JLabel("password");
        frame.add(password);
        password .setBounds(50, 110, 150, 100);
        
          JLabel cellphonenumber= new JLabel("cellphone");
        frame.add(cellphonenumber);
        cellphonenumber .setBounds(50, 140, 150, 100);
        
        JTextField textusername = new JTextField();
        frame.add(textusername);
        textusername.setBounds(155, 120, 150, 26);
        
          JTextField textpassword = new JTextField();
        frame.add(textpassword);
        textpassword.setBounds(155, 150, 150, 26);
                
                  JTextField textcellphonenumber = new JTextField();
        frame.add(textcellphonenumber);
        textcellphonenumber.setBounds(155, 180, 150, 26);
        
        JButton button = new JButton("Register");
        frame.add(button);
        button.setBounds(150, 230, 100, 26);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user, password , cellPhone;
                user = textusername.getText();
                password = textpassword.getText();
                cellPhone = cellphonenumber.getText();
                JOptionPane.showMessageDialog(null, registerUser(user, password, cellPhone));
             if(checkUsername(user) == true && checkcellphonenumber(cellPhone)&& checkpasswordcomplexity(password)){
                 cell[num]= cellPhone;
                 pass[num]= password;
                 userN[num]= user;
                 num++;
             }
            }
        });
                
                JButton button2 = new JButton("login");
                frame.add(button2);
                button2.setBounds(150, 260,100, 26);
                button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
           }
                });
    }

        public static void login(){
             JFrame frame = new JFrame("Login to BigScar");
        frame.setVisible(true);
        frame.setSize(450,450);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Color.CYAN);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setLayout(null);
        
        JLabel label= new JLabel("Welcome to BigScar , please login");
        frame.add(label);
        label .setBounds(40, 30, 250, 100);
        
          JLabel username= new JLabel("username");
        frame.add(username);
        username .setBounds(50, 80, 150, 100);
        
          JLabel password= new JLabel("password");
        frame.add(password);
        password .setBounds(50, 110, 150, 100);
        
         
        
        JTextField textusername = new JTextField();
        frame.add(textusername);
        textusername.setBounds(155, 120, 150, 26);
        
          JTextField textpassword = new JTextField();
        frame.add(textpassword);
        textpassword.setBounds(155, 150, 150, 26);
                
             
        
        JButton button = new JButton("Register");
        frame.add(button);
        button.setBounds(150, 230, 100, 26);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user, password ;
                user = textusername.getText();
                password = textpassword.getText();
                loginUser(user, password);
                JOptionPane.showMessageDialog(null, returnLoginStatus(user, password));
            }
        });
        }
        
                 
           //checking username  
        public static boolean checkUsername(String username){
            if(username.length() <=5&&username.contains("_")){
                return true;
            }
            else{
                return false;
            }
            
            
        }
        //checking password
        public static boolean checkpasswordcomplexity(String password){
            boolean hasUppercase = password.matches(".*[A-Z].*");
            boolean hasDigit = password.matches(".*\\d.*");
            boolean hasSpecial = password.matches(".*[!@#$%^&*()].*");
            boolean hasLength = password.length()>=8;
            return hasUppercase && hasDigit && hasSpecial && hasLength;
            
        }
        // checking cellphone number
        public static boolean checkcellphonenumber(String cellphonenumber){
           String zarcode="+27";
           String index= cellphonenumber.substring(0,3);
           int digit = Character.getNumericValue(cellphonenumber.charAt(3));
           
           
                   
    
            if(cellphonenumber.length()<=12 && index.equals(zarcode)&&digit>=6&&digit<=8){
               return true;
            }else{
                return false;
            }
        }
        public static String registerUser(String username, String password,String phone){
            boolean correctPassword = checkpasswordcomplexity(password);
            boolean correctUsername = checkUsername(username);
            boolean correctCellphone = checkcellphonenumber(phone);
            
            if(correctCellphone == true && correctPassword== true && correctUsername == true ){
                
            return "Sucessfully logged into BigScar";
        }else
            {
        return "Unable to login,Please try again";
        }            
        }
        public static boolean loginUser(String username,String password) {
             
            boolean correctUsername = checkUsername(username);
            boolean correctPassword = checkpasswordcomplexity(password);
            
            if(correctUsername == true && correctPassword==true){
                return true;
            }
            else{
                return false;
            }   
            }
        
        public static String returnLoginStatus(String username,String password){
            for(int i=0;i<num;i++){
                if(userN[i].equals(num)&& pass[i].equals(num)){
                    return "You have successfully logged in";
                }
                   return "Failed to log in!!" ;
                    
                    }
            boolean correctUsername = checkUsername(username);
            boolean correctPassword = checkpasswordcomplexity(password);
        
        if(correctUsername == true && correctPassword == true){
    return "Succesfully logged into BigSCAR";
        }
        else{
            return "login failed ";
            
    }
   
            
            
        }
         }
     



