/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part3;

import javax.swing.*;
import java.io.*;      
import java.util.*;    

public class Part3 {
    public static void main(String[] args) {

        // Class to handle user registration and login
        class User {
            String username;
            String password;
            String phoneNumber;
            boolean registered = false;

            // Check if username is valid (has _ and 5 letters or less)
            boolean isValidUsername(String username) {
                return username.contains("_") && username.length() <= 5;
            }

            // Checking if password is valid 
            boolean isValidPassword(String password) {
                return password.length() >= 8 && password.matches(".*[A-Z].*") &&
                        password.matches(".*\\d.*") && password.matches(".*[^a-zA-Z0-9].*");
            }

            // Checking if phone number starts with +27 and has 9 digits after
            boolean isValidPhoneNumber(String phone) {
                return phone.matches("\\+27\\d{9}");
            }

            // Register a new user
            String register(String username, String password, String phone) {
                if (!isValidUsername(username))
                    return "Username must contain '_' and be at most 5 characters.";
                if (!isValidPassword(password))
                    return "Password must be at least 8 characters with uppercase, number, and special char.";
                if (!isValidPhoneNumber(phone))
                    return "Phone number must start with +27 and have 9 digits.";

                this.username = username;
                this.password = password;
                this.phoneNumber = phone;
                this.registered = true;
                return "Registration successful!";
            }

            // Checking if login info is correct
            boolean login(String username, String password) {
                return registered && this.username.equals(username) && this.password.equals(password);
            }
        }

        // Checking message sent from one user to another
        class ChatMessage implements Serializable {
            String id;          
            String recipientPhone; 
            String content;       

            ChatMessage(String id, String recipientPhone, String content) {
                this.id = id;
                this.recipientPhone = recipientPhone;
                this.content = content;
            }
        }

        // Handles sending, storing, and reporting messages
        class MessageHandler {
            private ArrayList<ChatMessage> allMessages; // list of all messages
            private final User user;
            private final String FILE_NAME = "chatMessages.dat"; // file to save messages

            // Arrays 
            private String[] sentMessages = new String[100];
            private String[] disregardedMessages = new String[100];
            private String[] storedMessages = new String[100];
            private String[] messageHashes = new String[100];
            private String[] messageIDs = new String[100];
            private int sentCount = 0, disregardCount = 0, storedCount = 0, hashCount = 0, idCount = 0;

            MessageHandler(User user) {
                this.user = user;
                allMessages = new ArrayList<>();
                // load message from file
                loadMessages(); 
            }

            // Load saved messages from file
            void loadMessages() {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
                    allMessages = (ArrayList<ChatMessage>) ois.readObject();
                    for (ChatMessage m : allMessages) {
                        storedMessages[storedCount++] = m.content;
                        messageIDs[idCount++] = m.id;
                        messageHashes[hashCount++] = Integer.toHexString(m.content.hashCode());
                    }
                } catch (Exception e) {
                    allMessages = new ArrayList<>();
                }
            }

            // Save messages to file
            void saveMessages() {
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
                    oos.writeObject(allMessages);
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage());
                }
            }

            // Make a random  10-digit message ID
            String generateMessageId() {
                Random random = new Random();
                String id;
                do {
                    id = String.format("%010d", random.nextInt(1_000_000_000));
                } while (idExists(id));
                return id;
            }

            // Check if the ID already exists
            boolean idExists(String id) {
                for (ChatMessage m : allMessages) {
                    if (m.id.equals(id)) return true;
                }
                return false;
            }

            // Check if recipient's number is valid
            boolean isValidRecipient(String phone) {
                return user.isValidPhoneNumber(phone);
            }

            // Let user send a new message
            void sendMessage() {
                String recipient = JOptionPane.showInputDialog("Enter recipient phone number (+27XXXXXXXXX):");
                if (recipient == null || !isValidRecipient(recipient)) {
                    JOptionPane.showMessageDialog(null, "Invalid or cancelled phone number.");
                    return;
                }

                String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                if (message == null || message.length() > 250) {
                    JOptionPane.showMessageDialog(null, "Invalid or too long message.");
                    return;
                }
                // create id
                String msgId = generateMessageId();
                //create hash of message
                String hash = Integer.toHexString(message.hashCode()); 

                // Ask user what to do with the message
                Object[] options = {"Send", "Store", "Disregard"};
                int choice = JOptionPane.showOptionDialog(null, "Message ID: " + msgId +
                                "\nTo: " + recipient +
                                "\nMessage: " + message +
                                "\nChoose what to do:", "Confirm Message",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                // using if message on users choice
                if (choice == 0) {
                    // Send message
                    ChatMessage newMessage = new ChatMessage(msgId, recipient, message);
                    allMessages.add(newMessage);
                    sentMessages[sentCount++] = message;
                    messageIDs[idCount++] = msgId;
                    messageHashes[hashCount++] = hash;
                    saveMessages();
                    JOptionPane.showMessageDialog(null, "Message sent and saved!");
                } else if (choice == 1) {
                    // Store message only
                    storedMessages[storedCount++] = message;
                    messageIDs[idCount++] = msgId;
                    messageHashes[hashCount++] = hash;
                    saveMessages();
                    JOptionPane.showMessageDialog(null, "Message stored.");
                } else {
                    // Do nothing with message
                    disregardedMessages[disregardCount++] = message;
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
            }

            // Show last 5 messages
            void showRecentMessages() {
                if (allMessages.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No messages to show.");
                    return;
                }
                StringBuilder sb = new StringBuilder();
                int start = Math.max(0, allMessages.size() - 5);
                for (int i = allMessages.size() - 1; i >= start; i--) {
                    ChatMessage msg = allMessages.get(i);
                    sb.append("ID: ").append(msg.id)
                      .append(", To: ").append(msg.recipientPhone)
                      .append(", Msg: ").append(msg.content)
                      .append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString(), "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
            }

            // Show report of sent messages
            void displayReport() {
                StringBuilder sb = new StringBuilder("--- Sent Messages Report ---\n");
                for (int i = 0; i < sentCount; i++) {
                    sb.append("Hash: ").append(messageHashes[i]).append("\n")
                      .append("ID: ").append(messageIDs[i]).append("\n")
                      .append("Message: ").append(sentMessages[i]).append("\n---\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        }

        //  make new user object
        User user = new User();

        // Loop to register until successful
        while (true) {
            String username = JOptionPane.showInputDialog("Register - Enter username:");
            String password = JOptionPane.showInputDialog("Register - Enter password:");
            String phone = JOptionPane.showInputDialog("Register - Enter phone number (+27XXXXXXXXX):");
            if (username == null || password == null || phone == null) return;
            String result = user.register(username.trim(), password.trim(), phone.trim());
            JOptionPane.showMessageDialog(null, result);
            if (result.equals("Registration successful!")) break;
        }

        // Get user name
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        // return to login until correct
        boolean loggedIn = false;
        while (!loggedIn) {
            String username = JOptionPane.showInputDialog("Login - Enter username:");
            String password = JOptionPane.showInputDialog("Login - Enter password:");
            if (username == null || password == null) return;
            loggedIn = user.login(username.trim(), password.trim());
            JOptionPane.showMessageDialog(null, loggedIn ? "Welcome " + firstName + " " + lastName + "!" : "Wrong login.");
        }

        // Make a message handler for logged in user
        MessageHandler messageHandler = new MessageHandler(user);

        // Menu loop
        while (true) {
            String choice = JOptionPane.showInputDialog("Menu:\n1. Send Message\n2. View Recent Messages\n3. View Report\n4. Quit");
            if (choice == null) break;
            switch (choice) {
                case "1" -> messageHandler.sendMessage();       
                case "2" -> messageHandler.showRecentMessages(); 
                case "3" -> messageHandler.displayReport();      
                case "4" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    // exit 
                    return; 
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
}
  

